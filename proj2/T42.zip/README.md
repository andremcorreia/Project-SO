Andre Correia ist1102666 | Tiago Firmino ist1103590
O exercicio 2 encontra-se realizado na sua totalidade, pensamos ter todas as funcionalidades requeridas pelo enunciado operacionais, apenas adicionamos um ficheiro .c para a queue. 

A funcao cleanPipe() encontra se em todos os ficheiros em que e utilizado isto esta assim porque nao tinhamos a certeza se podiamos alterar algum ficheiro incluido por todos, ou incluir um dos existente nos outros, ou mesmo criar um file novo e como se tratava apenas de uma pequena funcao para limpeza de ficheiros pipe do sistema decidimos deixar assim.
